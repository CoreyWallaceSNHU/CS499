from dash import Dash, dcc, html, Input, Output, dash_table
import plotly.express as px
import pandas as pd
import base64

from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username='aacuser', password='CWallaceSNHU', host='nv-desktop-services.apporto.com', port=34067, db_name='AAC', collection_name='animals'):
        """Initialize MongoDB connection"""
        try:
            self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/")
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
        except PyMongoError as e:
            print(f"Connection error: {e}")
            raise

    def create(self, data):
        """Insert a document into the collection"""
        if data:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except PyMongoError as e:
                print(f"Create error: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, query):
        """Query documents from the collection"""
        if query:
            try:
                return list(self.collection.find(query))
            except PyMongoError as e:
                print(f"Read error: {e}")
                return []
        else:
            raise ValueError("Query parameter is empty")

    def update(self, query, new_values):
        """Update document(s) in the collection"""
        if query and new_values:
            try:
                result = self.collection.update_many(query, {'$set': new_values})
                return result.modified_count
            except PyMongoError as e:
                print(f"Update error: {e}")
                return 0
        else:
            raise ValueError("Query or new_values parameter is empty")

    def delete(self, query):
        """Delete document(s) from the collection"""
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except PyMongoError as e:
                print(f"Delete error: {e}")
                return 0
        else:
            raise ValueError("Query parameter is empty")
