///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ===============
// Manages camera, view/projection matrices, input handling and window setup
//
// AUTHOR:    Brian Battersby (original)
//            Refactored & modernized 2025–2026
// COURSE:    CS-330 Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <GLFW/glfw3.h>

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

#include <iostream>
#include <memory>

// ────────────────────────────────────────────────
// Constants
// ────────────────────────────────────────────────
namespace
{
    constexpr int   DEFAULT_WIDTH = 1280;
    constexpr int   DEFAULT_HEIGHT = 720;
    constexpr float DEFAULT_FOV = 75.0f;
    constexpr float NEAR_PLANE = 0.1f;
    constexpr float FAR_PLANE = 150.0f;
    constexpr float CAMERA_SPEED = 8.5f;
    constexpr float MOUSE_SENSITIVITY = 0.08f;

    constexpr const char* UNIFORM_VIEW = "view";
    constexpr const char* UNIFORM_PROJECTION = "projection";
}

// Static wrapper for GLFW callbacks (GLFW doesn't support member functions directly)
static ViewManager* s_instance = nullptr;

static void glfw_mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (s_instance) s_instance->HandleMouseMovement(xpos, ypos);
}

static void glfw_scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (s_instance) s_instance->HandleMouseScroll(yoffset);
}

// ────────────────────────────────────────────────
// Constructor / Destructor
// ────────────────────────────────────────────────
ViewManager::ViewManager(ShaderManager* shaderManager)
    : m_shaderManager(shaderManager),
    m_window(nullptr),
    m_camera(std::make_unique<Camera>()),
    m_lastX(DEFAULT_WIDTH / 2.0f),
    m_lastY(DEFAULT_HEIGHT / 2.0f),
    m_firstMouse(true),
    m_deltaTime(0.0f),
    m_lastFrame(0.0f),
    m_useOrthographic(false)
{
    s_instance = this;

    // Default camera settings
    m_camera->Position = glm::vec3(0.0f, 4.5f, 12.0f);
    m_camera->Front = glm::normalize(glm::vec3(0.0f, -0.4f, -1.0f));
    m_camera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    m_camera->MovementSpeed = CAMERA_SPEED;
    m_camera->MouseSensitivity = MOUSE_SENSITIVITY;
    m_camera->Zoom = DEFAULT_FOV;
}

ViewManager::~ViewManager()
{
    s_instance = nullptr;
    // camera is automatically cleaned up via unique_ptr
}

// ────────────────────────────────────────────────
// Window creation + input setup
// ────────────────────────────────────────────────
GLFWwindow* ViewManager::CreateDisplayWindow(const char* title, int width, int height)
{
    if (width <= 0 || height <= 0)
    {
        width = DEFAULT_WIDTH;
        height = DEFAULT_HEIGHT;
    }

    m_window = glfwCreateWindow(width, height, title, nullptr, nullptr);
    if (!m_window)
    {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(m_window);

    // Capture mouse
    glfwSetInputMode(m_window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Register callbacks
    glfwSetCursorPosCallback(m_window, glfw_mouse_callback);
    glfwSetScrollCallback(m_window, glfw_scroll_callback);

    // Enable transparency support
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    return m_window;
}

// ────────────────────────────────────────────────
// Input handling
// ────────────────────────────────────────────────
void ViewManager::ProcessInput()
{
    if (!m_window) return;

    float delta = m_deltaTime;

    // Exit on ESC
    if (glfwGetKey(m_window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_window, true);

    // Camera movement (WASD + QE)
    if (glfwGetKey(m_window, GLFW_KEY_W) == GLFW_PRESS)
        m_camera->ProcessKeyboard(FORWARD, delta);
    if (glfwGetKey(m_window, GLFW_KEY_S) == GLFW_PRESS)
        m_camera->ProcessKeyboard(BACKWARD, delta);
    if (glfwGetKey(m_window, GLFW_KEY_A) == GLFW_PRESS)
        m_camera->ProcessKeyboard(LEFT, delta);
    if (glfwGetKey(m_window, GLFW_KEY_D) == GLFW_PRESS)
        m_camera->ProcessKeyboard(RIGHT, delta);
    if (glfwGetKey(m_window, GLFW_KEY_Q) == GLFW_PRESS)
        m_camera->ProcessKeyboard(UP, delta);
    if (glfwGetKey(m_window, GLFW_KEY_E) == GLFW_PRESS)
        m_camera->ProcessKeyboard(DOWN, delta);

    // Projection toggle (P = perspective, O = orthographic)
    if (glfwGetKey(m_window, GLFW_KEY_P) == GLFW_PRESS)
    {
        m_useOrthographic = false;
        ResetPerspectiveCamera();
    }
    if (glfwGetKey(m_window, GLFW_KEY_O) == GLFW_PRESS)
    {
        m_useOrthographic = true;
        ResetOrthoCamera();
    }

    // Quick ortho views (1=front, 2=side, 3=top)
    if (glfwGetKey(m_window, GLFW_KEY_1) == GLFW_PRESS) SetOrthoFront();
    if (glfwGetKey(m_window, GLFW_KEY_2) == GLFW_PRESS) SetOrthoSide();
    if (glfwGetKey(m_window, GLFW_KEY_3) == GLFW_PRESS) SetOrthoTop();
}

void ViewManager::HandleMouseMovement(double xpos, double ypos)
{
    if (m_firstMouse)
    {
        m_lastX = xpos;
        m_lastY = ypos;
        m_firstMouse = false;
    }

    float xoffset = xpos - m_lastX;
    float yoffset = m_lastY - ypos; // reversed y

    m_lastX = xpos;
    m_lastY = ypos;

    m_camera->ProcessMouseMovement(xoffset, yoffset);
}

void ViewManager::HandleMouseScroll(double yoffset)
{
    m_camera->ProcessMouseScroll(static_cast<float>(yoffset));
}

// ────────────────────────────────────────────────
// View / Projection setup (called each frame)
// ────────────────────────────────────────────────
void ViewManager::PrepareSceneView()
{
    if (!m_shaderManager || !m_window) return;

    // ── Update timing ────────────────────────────────────────
    float currentFrame = static_cast<float>(glfwGetTime());
    m_deltaTime = currentFrame - m_lastFrame;
    m_lastFrame = currentFrame;

    // ── Handle input ─────────────────────────────────────────
    ProcessInput();

    // ── Get current window size (supports resizing) ──────────
    int width, height;
    glfwGetFramebufferSize(m_window, &width, &height);
    glViewport(0, 0, width, height);

    float aspect = static_cast<float>(width) / static_cast<float>(height);

    // ── View matrix ──────────────────────────────────────────
    glm::mat4 view = m_camera->GetViewMatrix();

    // ── Projection matrix ────────────────────────────────────
    glm::mat4 projection;
    if (m_useOrthographic)
    {
        // Orthographic – adjust size based on scene scale
        float orthoSize = 12.0f;
        projection = glm::ortho(-orthoSize * aspect, orthoSize * aspect,
            -orthoSize, orthoSize,
            0.1f, 200.0f);
    }
    else
    {
        projection = glm::perspective(glm::radians(m_camera->Zoom),
            aspect,
            NEAR_PLANE,
            FAR_PLANE);
    }

    // ── Upload to shader ─────────────────────────────────────
    m_shaderManager->setMat4Value(UNIFORM_VIEW, view);
    m_shaderManager->setMat4Value(UNIFORM_PROJECTION, projection);
    m_shaderManager->setVec3Value("viewPosition", m_camera->Position);

    // Attach spotlight to camera (flashlight effect)