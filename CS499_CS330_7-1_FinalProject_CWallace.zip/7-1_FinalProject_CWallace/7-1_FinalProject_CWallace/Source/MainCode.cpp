///////////////////////////////////////////////////////////////////////////////
// main.cpp
// ========
// Application entry point — initializes GLFW, GLEW, managers and main loop
//
// AUTHOR:    Brian Battersby (original), refactored & modernized
// COURSE:    CS-330 Computational Graphics and Visualization
// UPDATED:   2025-2026
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <memory>           // std::unique_ptr
#include <cstdlib>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShaderManager.h"

// ────────────────────────────────────────────────
// Globals / Constants
// ────────────────────────────────────────────────
namespace
{
    constexpr const char* WINDOW_TITLE = "CS-330 Final Project - 3D Desk Scene";
    constexpr int         INITIAL_WIDTH = 1280;
    constexpr int         INITIAL_HEIGHT = 720;

    GLFWwindow* window = nullptr;
}

// Forward declarations
bool initGLFW();
bool initGLEW();
void glfwErrorCallback(int error, const char* description);
void framebufferSizeCallback(GLFWwindow* window, int width, int height);

// ────────────────────────────────────────────────
// Main application entry point
// ────────────────────────────────────────────────
int main(int /*argc*/, char* /*argv*/[])
{
    // ─── 1. Initialize libraries ────────────────────────────────
    if (!initGLFW())
    {
        std::cerr << "Failed to initialize GLFW\n";
        return EXIT_FAILURE;
    }

    // ─── 2. Create managers (using RAII / unique_ptr) ───────────
    auto shaderManager = std::make_unique<ShaderManager>();
    auto viewManager = std::make_unique<ViewManager>(shaderManager.get());
    auto sceneManager = std::make_unique<SceneManager>(shaderManager.get());

    // ─── 3. Create window ───────────────────────────────────────
    window = viewManager->CreateDisplayWindow(WINDOW_TITLE, INITIAL_WIDTH, INITIAL_HEIGHT);
    if (!window)
    {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return EXIT_FAILURE;
    }

    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);

    // ─── 4. Initialize GLEW after context is current ────────────
    if (!initGLEW())
    {
        glfwDestroyWindow(window);
        glfwTerminate();
        return EXIT_FAILURE;
    }

    // ─── 5. Load & activate shader program ──────────────────────
    if (!shaderManager->LoadShaders("shaders/vertexShader.glsl",
        "shaders/fragmentShader.glsl"))
    {
        std::cerr << "Failed to load shaders\n";
        glfwDestroyWindow(window);
        glfwTerminate();
        return EXIT_FAILURE;
    }
    shaderManager->use();

    // ─── 6. Prepare scene ───────────────────────────────────────
    sceneManager->PrepareScene();

    // ─── 7. Main render loop ────────────────────────────────────
    std::cout << "Entering main loop...\n";

    while (!glfwWindowShouldClose(window))
    {
        float currentTime = static_cast<float>(glfwGetTime());

        // ── Clear frame ──
        glClearColor(0.08f, 0.12f, 0.18f, 1.0f);  // nicer dark background
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glEnable(GL_DEPTH_TEST);

        // Update view (projection, camera)
        viewManager->PrepareSceneView();

        // Render actual scene
        sceneManager->RenderScene();

        // Swap buffers & process events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    std::cout << "Exiting main loop.\n";

    // ─── 8. Cleanup (RAII takes care of most things) ────────────
    sceneManager.reset();
    viewManager.reset();
    shaderManager.reset();

    glfwDestroyWindow(window);
    glfwTerminate();

    return EXIT_SUCCESS;
}

// ────────────────────────────────────────────────
// GLFW Initialization
// ────────────────────────────────────────────────
bool initGLFW()
{
    glfwSetErrorCallback(glfwErrorCallback);

    if (!glfwInit())
    {
        std::cerr << "GLFW initialization failed\n";
        return false;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 5);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);     // macOS
    glfwWindowHint(GLFW_SAMPLES, 4);           // MSAA ×4

    // Optional: request sRGB framebuffer
    // glfwWindowHint(GLFW_SRGB_CAPABLE, GLFW_TRUE);

    return true;
}

// ────────────────────────────────────────────────
// GLEW Initialization
// ────────────────────────────────────────────────
bool initGLEW()
{
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (err != GLEW_OK)
    {
        std::cerr << "GLEW initialization failed: " << glewGetErrorString(err) << "\n";
        return false;
    }

    std::cout << "OpenGL Version:  " << glGetString(GL_VERSION) << "\n";
    std::cout << "GLSL Version:    " << glGetString(GL_SHADING_LANGUAGE_VERSION) << "\n";
    std::cout << "Renderer:        " << glGetString(GL_RENDERER) << "\n\n";

    return true;
}

// ────────────────────────────────────────────────
// GLFW error callback
// ────────────────────────────────────────────────
void glfwErrorCallback(int error, const char* description)
{
    std::cerr << "GLFW Error " << error << ": " << description << "\n";
}

// ────────────────────────────────────────────────
// Window resize handler
// ────────────────────────────────────────────────
void framebufferSizeCallback(GLFWwindow* /*window*/, int width, int height)
{
    glViewport(0, 0, width, height);

    // You can also update projection matrix here if ViewManager doesn't handle it
    // g_ViewManager->UpdateProjection(width, height);
}