///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// Implementation of the SceneManager class - manages preparation and rendering
// of 3D scenes, textures, materials, lighting, and object transformations.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: February 2026 (refactored for readability & animation)
//               Updated lighting: brighter, more realistic (Feb 2026)
//
// RESPONSIBILITIES:
// - Load and manage OpenGL textures (using stb_image)
// - Define materials and lighting
// - Handle transformations and shader uniforms
// - Render scene using basic meshes
///////////////////////////////////////////////////////////////////////////////
#include "SceneManager.h"
#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>
#include <GLFW/glfw3.h> // for glfwGetTime() — adjust if using different windowing

// ────────────────────────────────────────────────
// Anonymous namespace for constants & globals
// ────────────────────────────────────────────────
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";

    // Animation tuning
    constexpr float ROTATION_SPEED_DEG_PER_SEC = 35.0f;
    constexpr float BOBBING_SPEED = 1.6f;
    constexpr float BOBBING_AMPLITUDE = 0.08f;

    // Common small key dimensions
    constexpr glm::vec3 KEY_SCALE_DEFAULT{ 0.60f, 0.60f, 0.60f };
    constexpr float KEY_Y_POS = 0.10f;
}

// ────────────────────────────────────────────────
// Constructor / Destructor
// ────────────────────────────────────────────────
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    // Initialize texture slots
    for (int i = 0; i < 16; ++i)
    {
        m_textureIDs[i].tag = "/0";
        m_textureIDs[i].ID = -1;
    }
    m_loadedTextures = 0;
}

SceneManager::~SceneManager()
{
    m_pShaderManager = nullptr;
    delete m_basicMeshes;
    m_basicMeshes = nullptr;
}

// ────────────────────────────────────────────────
// Texture Management
// ────────────────────────────────────────────────
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, channels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (!image)
    {
        std::cout << "Failed to load texture: " << filename << std::endl;
        return false;
    }

    std::cout << "Loaded texture: " << filename
        << " (" << width << "×" << height << ", " << channels << " channels)\n";

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    GLenum format = (channels == 4) ? GL_RGBA : GL_RGB;
    GLenum internal = (channels == 4) ? GL_RGBA8 : GL_RGB8;

    glTexImage2D(GL_TEXTURE_2D, 0, internal, width, height, 0,
        format, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Store in array
    if (m_loadedTextures < 16)
    {
        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = std::move(tag);
        m_loadedTextures++;
    }

    return true;
}

void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        GLuint id = m_textureIDs[i].ID;
        if (id != 0) glDeleteTextures(1, &id);
        m_textureIDs[i].ID = 0;
    }
    m_loadedTextures = 0;
}

int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        if (m_textureIDs[i].tag == tag)
            return i;
    }
    return -1;
}

int SceneManager::FindTextureID(std::string tag)
{
    int slot = FindTextureSlot(tag);
    return (slot >= 0) ? m_textureIDs[slot].ID : -1;
}

// ────────────────────────────────────────────────
// Material & Shader Helpers
// ────────────────────────────────────────────────
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& outMaterial)
{
    for (const auto& mat : m_objectMaterials)
    {
        if (mat.tag == tag)
        {
            outMaterial = mat;
            return true;
        }
    }
    return false;
}

void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float rotX_deg, float rotY_deg, float rotZ_deg,
    glm::vec3 positionXYZ)
{
    glm::mat4 scaleMat = glm::scale(scaleXYZ);
    glm::mat4 rotX = glm::rotate(glm::radians(rotX_deg), glm::vec3(1, 0, 0));
    glm::mat4 rotY = glm::rotate(glm::radians(rotY_deg), glm::vec3(0, 1, 0));
    glm::mat4 rotZ = glm::rotate(glm::radians(rotZ_deg), glm::vec3(0, 0, 1));
    glm::mat4 translate = glm::translate(positionXYZ);

    glm::mat4 model = translate * rotZ * rotY * rotX * scaleMat;

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
    }
}

void SceneManager::SetShaderTexture(const std::string& tag, float uvScaleU, float uvScaleV)
{
    if (!m_pShaderManager) return;

    int slot = FindTextureSlot(tag);
    if (slot >= 0)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(uvScaleU, uvScaleV));
    }
}

void SceneManager::SetShaderMaterial(const std::string& tag)
{
    OBJECT_MATERIAL mat;
    if (FindMaterial(tag, mat) && m_pShaderManager)
    {
        m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
    }
}

// ────────────────────────────────────────────────
// Scene Preparation
// ────────────────────────────────────────────────
void SceneManager::LoadSceneTextures()
{
    CreateGLTexture("textures/pentip.jpg", "pentip");
    CreateGLTexture("textures/keyboard.jpeg", "keyboard");
    CreateGLTexture("textures/plasticpen.jpg", "plasticpen");
    CreateGLTexture("textures/table.jpg", "table");
    CreateGLTexture("textures/baseball.jpg", "baseball");
    CreateGLTexture("textures/airduster.jpg", "airduster");
    CreateGLTexture("textures/desk.jpg", "desk");

    BindGLTextures();
}

void SceneManager::DefineObjectMaterials()
{
    m_objectMaterials.clear();
    OBJECT_MATERIAL m;

    // Metal – shinier, more reflective
    m.tag = "metal";
    m.diffuseColor = glm::vec3(0.55f, 0.55f, 0.57f);
    m.specularColor = glm::vec3(0.95f, 0.93f, 0.90f);
    m.shininess = 120.0f;           // tighter, brighter highlights
    m_objectMaterials.push_back(m);

    // Plastic – improved specular for realistic sheen
    m.tag = "plastic";
    m.diffuseColor = glm::vec3(0.48f, 0.46f, 0.50f);
    m.specularColor = glm::vec3(0.80f, 0.78f, 0.75f);
    m.shininess = 45.0f;            // increased for better plastic appearance
    m_objectMaterials.push_back(m);

    // Wood – subtle specular
    m.tag = "wood";
    m.diffuseColor = glm::vec3(0.38f, 0.24f, 0.14f);  // richer tone
    m.specularColor = glm::vec3(0.12f, 0.09f, 0.06f);
    m.shininess = 8.0f;
    m_objectMaterials.push_back(m);
}

void SceneManager::SetupSceneLights()
{
    if (!m_pShaderManager) return;
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // ─── Directional Light (bright daylight / sun-like) ─────────────────────────────
    m_pShaderManager->setVec3Value("directionalLight.direction", glm::normalize(glm::vec3(0.4f, -0.9f, -0.5f)));
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.28f, 0.26f, 0.24f);   // stronger ambient
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.92f, 0.88f, 0.80f);   // bright, warm daylight
    m_pShaderManager->setFloatValue("directionalLight.specular", 0.45f);                // stronger highlights

    // ─── Point Light 1 (warm ceiling/room light – left side) ─────────────────────────
    m_pShaderManager->setVec3Value("pointLights[0].position", 4.0f, 8.0f, 2.0f);
    m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.08f, 0.06f, 0.04f);
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.95f, 0.88f, 0.75f);   // warm white
    m_pShaderManager->setVec3Value("pointLights[0].specular", 0.60f, 0.55f, 0.45f);
    m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[0].linear", 0.045f);
    m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.0075f);

    // ─── Point Light 2 (cool fill light – right/back side) ───────────────────────────
    m_pShaderManager->setVec3Value("pointLights[1].position", -3.0f, 6.0f, 5.0f);
    m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.05f, 0.06f, 0.08f);
    m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.80f, 0.85f, 0.95f);   // slightly cooler fill
    m_pShaderManager->setVec3Value("pointLights[1].specular", 0.40f, 0.45f, 0.50f);
    m_pShaderManager->setFloatValue("pointLights[1].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[1].linear", 0.07f);
    m_pShaderManager->setFloatValue("pointLights[1].quadratic", 0.017f);

    // Tell shader how many point lights are active
    m_pShaderManager->setIntValue("numPointLights", 2);

    // Optional: global exposure/brightness control (if your shader supports it)
    // m_pShaderManager->setFloatValue("exposure", 1.2f);
}

// ────────────────────────────────────────────────
// Helper draw function
// ────────────────────────────────────────────────
void SceneManager::DrawMesh(
    MeshType meshType,
    const glm::vec3& scale,
    float rotX, float rotY, float rotZ,
    const glm::vec3& pos,
    const std::string& textureTag = "",
    const std::string& materialTag = "plastic",
    float uvU = 1.0f, float uvV = 1.0f)
{
    SetTransformations(scale, rotX, rotY, rotZ, pos);

    if (!textureTag.empty())
        SetShaderTexture(textureTag, uvU, uvV);

    if (!materialTag.empty() && materialTag != "none")
        SetShaderMaterial(materialTag);

    switch (meshType)
    {
    case MeshType::Box:      m_basicMeshes->DrawBoxMesh();      break;
    case MeshType::Plane:    m_basicMeshes->DrawPlaneMesh();    break;
    case MeshType::Cylinder: m_basicMeshes->DrawCylinderMesh(); break;
    case MeshType::Cone:     m_basicMeshes->DrawConeMesh();     break;
    case MeshType::Sphere:   m_basicMeshes->DrawSphereMesh();   break;
    default: break;
    }
}

// ────────────────────────────────────────────────
// Main scene rendering (with smooth animation)
// ────────────────────────────────────────────────
void SceneManager::RenderScene()
{
    float t = static_cast<float>(glfwGetTime());
    float rotation = fmodf(t * ROTATION_SPEED_DEG_PER_SEC, 360.0f);
    float bob = sinf(t * BOBBING_SPEED) * BOBBING_AMPLITUDE;

    // ─── Desk / Table ───────────────────────────────────────
    DrawMesh(MeshType::Box, { 25.0f, 1.0f, 18.0f }, 0, 0, 0, { 0.0f, -0.7f, 5.0f }, "table");
    DrawMesh(MeshType::Plane, { 12.5f, 1.0f, 9.0f }, 90, 0, 0, { 0.0f, 8.0f, -4.0f }, "desk");

    // ─── Pen (rotating slowly) ──────────────────────────────
    DrawMesh(MeshType::Cylinder, { 0.10f, 2.50f, 0.10f }, 90, 45 + rotation, 0, { 4.00f, 0.10f, 2.30f }, "plasticpen");
    DrawMesh(MeshType::Cone, { 0.10f, 0.30f, 0.10f }, 90, 45 + rotation, 0, { 5.76f, 0.10f, 4.06f }, "pentip", "metal");

    // ─── Baseball (bobbing) ─────────────────────────────────
    DrawMesh(MeshType::Sphere, { 1.0f, 1.0f, 1.0f }, 90, 45, 0, { -1.76f, 0.80f + bob, 3.06f }, "baseball");

    // ─── Air duster ─────────────────────────────────────────
    DrawMesh(MeshType::Cylinder, { 0.8f, 5.5f, 0.8f }, 0, 0, 0, { 0.9f, 0.0f, 3.75f }, "airduster", "metal");
    DrawMesh(MeshType::Sphere, { 0.6f, 0.6f, 0.6f }, 0, 0, 0, { 0.9f, 5.4f, 3.75f }, "", "metal");
    DrawMesh(MeshType::Box, { 0.6f, 1.1f, 0.6f }, 0, 0, 0, { 0.9f, 5.9f, 3.75f }, "", "plastic");
    DrawMesh(MeshType::Cylinder, { 0.05f, 1.1f, 0.05f }, 90, 90, 0, { 0.9f, 6.2f, 3.75f }, "", "plastic"); // nozzle

    // ─── Keyboard ───────────────────────────────────────────
    DrawMesh(MeshType::Box, { 10.0f, 0.4f, 3.0f }, 0, 0, 0, { 0.3f, 0.0f, 6.66f }, "keyboard");

    // Example keys – expand as needed
    DrawMesh(MeshType::Box, KEY_SCALE_DEFAULT, 0, 0, 0, { -3.9f, KEY_Y_POS, 6.0f }, "", "plastic"); // ESC
    DrawMesh(MeshType::Box, KEY_SCALE_DEFAULT, 0, 0, 0, { -2.1f, KEY_Y_POS, 6.0f }, "", "plastic"); // F2
    // ... add more rows / function keys ...
}