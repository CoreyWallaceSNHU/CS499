/*
 * Corey Wallace
 * CS320
 * SNHU
 */

package main;  // lowercase package name is conventional

import java.util.HashMap;
import java.util.Map;

/**
 * Service class for managing Task objects.
 * Provides methods to add, delete, and update tasks using a unique ID.
 */
public final class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();
    private int nextId = 0;  // Simple counter for generating unique IDs

    /**
     * Adds a new task with the given name and description.
     * Automatically generates a unique ID.
     *
     * @param name        the name of the task (must not be null or invalid per Task rules)
     * @param description the description of the task (must not be null or invalid per Task rules)
     * @return the generated ID of the newly added task
     * @throws IllegalArgumentException if name or description is invalid
     */
    public String addTask(String name, String description) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Task name cannot be null or empty");
        }
        if (description == null || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Task description cannot be null or empty");
        }

        String id = String.valueOf(nextId++);
        Task task = new Task(id, name, description);
        tasks.put(id, task);
        return id;
    }

    /**
     * Removes a task by its ID if it exists.
     *
     * @param id the unique ID of the task to delete
     * @return true if a task was removed, false if the ID was not found
     */
    public boolean deleteTask(String id) {
        if (id == null) {
            return false;
        }
        return tasks.remove(id) != null;
    }

    /**
     * Updates the name and/or description of an existing task.
     *
     * @param id             the unique ID of the task to update
     * @param newName        the new name (can be null to keep existing)
     * @param newDescription the new description (can be null to keep existing)
     * @throws IllegalArgumentException if the task ID does not exist
     *                                  or if provided values are invalid per Task rules
     */
    public void updateTask(String id, String newName, String newDescription) {
        if (id == null || !tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task with ID " + id + " not found");
        }

        Task task = tasks.get(id);

        // Only update if non-null value is provided
        if (newName != null) {
            task.setName(newName);
        }
        if (newDescription != null) {
            task.setDescription(newDescription);
        }
    }

    /**
     * Returns the number of tasks currently stored.
     *
     * @return the current task count
     */
    public int getTaskCount() {
        return tasks.size();
    }

    /**
     * Returns the task with the specified ID, or null if not found.
     *
     * @param id the ID to look up
     * @return the Task object or null
     */
    public Task getTask(String id) {
        return tasks.get(id);
    }

    /**
     * Clears all tasks (mainly for testing purposes).
     */
    public void clearAllTasks() {
        tasks.clear();
        nextId = 0;  // Optional: reset ID counter
    }
}
