/*
 * Corey Wallace
 * CS320 - Software Testing
 * SNHU
 */

package main;  // ← lowercase is conventional for packages

import java.util.Date;

/**
 * Represents an appointment with a unique ID, future date, and description.
 * All fields are immutable except through validated setters.
 */
public class Appointment {

    private final String id;          // uniqueID → id (shorter, conventional)
    private Date date;
    private String description;

    // -------------------------------------------------------------------------
    // Validation methods (private, pure functions)
    // -------------------------------------------------------------------------

    private static boolean isValidId(String id) {
        return id != null &&
               !id.isBlank() &&
               id.length() <= 10;
    }

    private static boolean isValidDate(Date date) {
        return date != null && !date.before(new Date());
    }

    private static boolean isValidDescription(String description) {
        return description != null &&
               !description.isBlank() &&
               description.length() <= 50;
    }

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /**
     * Creates a new Appointment.
     *
     * @param id          unique identifier (max 10 characters, not null/empty)
     * @param date        appointment date (must be in the future)
     * @param description short description (max 50 characters, not null/empty)
     * @throws IllegalArgumentException if any parameter is invalid
     */
    public Appointment(String id, Date date, String description) {
        if (!isValidId(id)) {
            throw new IllegalArgumentException("Invalid appointment ID: must be 1-10 characters, non-null, non-blank");
        }
        if (!isValidDate(date)) {
            throw new IllegalArgumentException("Invalid date: must be non-null and in the future");
        }
        if (!isValidDescription(description)) {
            throw new IllegalArgumentException("Invalid description: must be 1-50 characters, non-null, non-blank");
        }

        this.id = id;
        this.date = date;           // Note: Date is mutable → consider defensive copy in production
        this.description = description;
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    /**
     * @return the unique appointment ID (String)
     */
    public String getId() {
        return id;
    }

    /**
     * @return the appointment date
     */
    public Date getDate() {
        return date;   // In production: consider returning a defensive copy
    }

    /**
     * @return the appointment description
     */
    public String getDescription() {
        return description;
    }

    // -------------------------------------------------------------------------
    // Setters (with validation)
    // -------------------------------------------------------------------------

    /**
     * Updates the appointment date.
     *
     * @param date new future date
     * @throws IllegalArgumentException if date is null or in the past
     */
    public void setDate(Date date) {
        if (!isValidDate(date)) {
            throw new IllegalArgumentException("Invalid date: must be non-null and in the future");
        }
        this.date = date;   // In production: consider defensive copy
    }

    /**
     * Updates the appointment description.
     *
     * @param description new description (1–50 characters)
     * @throws IllegalArgumentException if description is invalid
     */
    public void setDescription(String description) {
        if (!isValidDescription(description)) {
            throw new IllegalArgumentException("Invalid description: must be 1-50 characters, non-null, non-blank");
        }
        this.description = description;
    }

    // Note: No setter for ID because it should be immutable after creation
}