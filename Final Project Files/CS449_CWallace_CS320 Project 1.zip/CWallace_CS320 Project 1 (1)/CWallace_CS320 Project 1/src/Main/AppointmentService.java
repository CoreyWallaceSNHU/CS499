/*
 * Corey Wallace
 * CS320 - Software Testing
 * SNHU
 */

package main;  // ← lowercase is conventional for packages

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Service class responsible for managing a collection of Appointments.
 * Provides methods to add, delete, and (optionally) update appointments.
 * Uses a HashMap with String IDs for storage.
 */
public class AppointmentService {

    // In-memory storage of appointments (key = appointment ID)
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Simple incrementing counter for generating pseudo-unique IDs
    // Note: In a real system, consider UUID.randomUUID().toString() instead
    private int idCounter = 0;

    /**
     * Adds a new appointment with an auto-generated unique ID.
     *
     * @param date        the appointment date (must be in the future)
     * @param description the appointment description (1–50 characters)
     * @return the generated ID of the newly created appointment
     * @throws IllegalArgumentException if date or description is invalid
     */
    public String addAppointment(Date date, String description) {
        String id = generateNextId();
        Appointment appointment = new Appointment(id, date, description);

        appointments.put(id, appointment);
        return id;
    }

    /**
     * Removes an appointment by its ID.
     *
     * @param id the ID of the appointment to delete
     * @return true if an appointment was removed, false if ID not found
     */
    public boolean deleteAppointment(String id) {
        if (id == null) {
            return false;
        }
        return appointments.remove(id) != null;
    }

    /**
     * Updates the date and/or description of an existing appointment.
     *
     * @param id           the ID of the appointment to update
     * @param newDate      new date (may be null to leave unchanged)
     * @param newDescription new description (may be null to leave unchanged)
     * @throws IllegalArgumentException if ID not found or new values are invalid
     */
    public void updateAppointment(String id, Date newDate, String newDescription) {
        Appointment appointment = findAppointmentOrThrow(id);

        if (newDate != null) {
            appointment.setDate(newDate);
        }
        if (newDescription != null) {
            appointment.setDescription(newDescription);
        }
    }

    // -------------------------------------------------------------------------
    // Helper methods
    // -------------------------------------------------------------------------

    private String generateNextId() {
        return String.valueOf(idCounter++);
    }

    private Appointment findAppointmentOrThrow(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Appointment ID cannot be null or blank");
        }
        Appointment appointment = appointments.get(id);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment not found with ID: " + id);
        }
        return appointment;
    }

    // For testing / debugging purposes (optional)
    public int getAppointmentCount() {
        return appointments.size();
    }

    // Optional: expose read-only