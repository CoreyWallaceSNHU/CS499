/*
 * Corey Wallace
 * CS320 - Software Testing
 * SNHU
 */
package main; // ← use lowercase for packages (convention)

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Appointment class.
 * Validates constructor behavior and field validation rules.
 */
@DisplayName("Appointment Class Tests")
class AppointmentTest {

    private Date futureDate;
    private Date pastDate;

    @BeforeEach
    void setUp() {
        Calendar cal = Calendar.getInstance();
        // Future date: December 5, 2025
        cal.set(2025, Calendar.DECEMBER, 5, 10, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        futureDate = cal.getTime();

        // Past date: December 5, 1996
        cal.set(1996, Calendar.DECEMBER, 5);
        pastDate = cal.getTime();
    }

    @Nested
    @DisplayName("Happy Path – Valid Inputs")
    class ValidCreationTests {

        @Test
        @DisplayName("Valid appointment is created successfully")
        void shouldCreateAppointmentWithValidInputs() {
            String id = "1234567890"; // max length
            String description = "Doctor visit - annual checkup";

            Appointment appt = new Appointment(id, futureDate, description);

            assertEquals(id, appt.getId());
            assertEquals(futureDate, appt.getDate());
            assertEquals(description, appt.getDescription());
        }
    }

    @Nested
    @DisplayName("ID Validation")
    class IdValidationTests {

        @Test
        @DisplayName("Constructor throws exception when ID is null")
        void shouldThrowWhenIdIsNull() {
            assertThrowsExactlyMessage(
                "Invalid appointment ID: must be 1-10 characters, non-null, non-blank",
                () -> new Appointment(null, futureDate, "Valid desc")
            );
        }

        @Test
        @DisplayName("Constructor throws exception when ID is blank")
        void shouldThrowWhenIdIsBlank() {
            assertThrowsExactlyMessage(
                "Invalid appointment ID: must be 1-10 characters, non-null, non-blank",
                () -> new Appointment(" ", futureDate, "Valid desc")
            );
        }

        @Test
        @DisplayName("Constructor throws exception when ID is too long (>10 chars)")
        void shouldThrowWhenIdIsTooLong() {
            String tooLongId = "12345678901"; // 11 characters
            assertThrowsExactlyMessage(
                "Invalid appointment ID: must be 1-10 characters, non-null, non-blank",
                () -> new Appointment(tooLongId, futureDate, "Valid desc")
            );
        }
    }

    // You can easily add more nested classes later, e.g.:
    /*
    @Nested
    @DisplayName("Date Validation")
    class DateValidationTests {
        @Test
        void shouldThrowWhenDateIsNull() { ... }

        @Test
        void shouldThrowWhenDateIsInThePast() { ... }
    }

    @Nested
    @DisplayName("Description Validation")
    class DescriptionValidationTests {
        // ... tests for null, empty, blank, too long ...
    }
    */
}