/*
 * Corey Wallace
 * CS320
 * SNHU
 */

package Main;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

/**
 * Unit tests for the ContactService class.
 */
@DisplayName("ContactService Unit Tests")
class ContactServiceTest {

    private static final String VALID_FIRST_NAME  = "Greg";
    private static final String VALID_LAST_NAME   = "Hoffman";
    private static final String VALID_PHONE       = "1234567890";
    private static final String VALID_ADDRESS     = "123 Main Street";

    private ContactService contactService;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
        // Assuming ContactService.contactList is static → cleared via @AfterEach
    }

    @AfterEach
    void tearDown() {
        ContactService.contactList.clear();
    }

    // ───────────────────────────────────────────────
    //  Add Contact Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("addContact stores contact correctly and generates ID")
    void testAddContact_Success() {
        String returnedId = contactService.addContact(VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PHONE, VALID_ADDRESS);

        assertFalse(ContactService.contactList.isEmpty(), "Contact list should not be empty");
        assertEquals(1, ContactService.contactList.size(), "Should contain exactly one contact");

        Contact added = ContactService.contactList.get(0);
        assertEquals(returnedId, added.getContactID(), "Returned ID should match stored contact ID");
        assertEquals(VALID_FIRST_NAME, added.getFirstName());
        assertEquals(VALID_LAST_NAME,  added.getLastName());
        assertEquals(VALID_PHONE,      added.getPhoneNumber());
        assertEquals(VALID_ADDRESS,    added.getAddress());
    }

    // ───────────────────────────────────────────────
    //  Delete