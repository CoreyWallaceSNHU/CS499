/*
 * Corey Wallace
 * CS320
 * SNHU
 */

package Main;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Task Class Unit Tests")
class TaskTest {

    private static final String VALID_ID = "1234567890";
    private static final String VALID_NAME = "Greg Tippton";
    private static final String VALID_DESCRIPTION = "This is a valid task description";

    // ───────────────────────────────────────────────
    //  Constructor Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("Constructor accepts valid inputs")
    void testGoodConstructor() {
        Task task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);

        assertEquals(VALID_ID, task.getUniqueID());
        assertEquals(VALID_NAME, task.getName());
        assertEquals(VALID_DESCRIPTION, task.getDescription());
    }

    @Test
    @DisplayName("Constructor rejects null ID")
    void testConstructorNullId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, VALID_NAME, VALID_DESCRIPTION));
    }

    @Test
    @DisplayName("Constructor rejects too long ID")
    void testConstructorIdTooLong() {
        String tooLongId = "12345678901"; // assuming max is 10 characters
        assertThrows(IllegalArgumentException.class,
                () -> new Task(tooLongId, VALID_NAME, VALID_DESCRIPTION));
    }

    @Test
    @DisplayName("Constructor rejects null name")
    void testConstructorNullName() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(VALID_ID, null, VALID_DESCRIPTION));
    }

    @Test
    @DisplayName("Constructor rejects too long name")
    void testConstructorNameTooLong() {
        String tooLongName = "This name is way too long to be accepted here";
        assertThrows(IllegalArgumentException.class,
                () -> new Task(VALID_ID, tooLongName, VALID_DESCRIPTION));
    }

    @Test
    @DisplayName("Constructor rejects null description")
    void testConstructorNullDescription() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(VALID_ID, VALID_NAME, null));
    }

    @Test
    @DisplayName("Constructor rejects empty description")
    void testConstructorEmptyDescription() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(VALID_ID, VALID_NAME, ""));
    }

    @Test
    @DisplayName("Constructor rejects too long description")
    void testConstructorDescriptionTooLong() {
        String tooLongDesc = "This description is intentionally made very very long " +
                            "to exceed the maximum allowed length of fifty characters";
        assertThrows(IllegalArgumentException.class,
                () -> new Task(VALID_ID, VALID_NAME, tooLongDesc));
    }

    // ───────────────────────────────────────────────
    //  Setter Tests – Name
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("setName() accepts valid name")
    void testSetNameValid() {
        Task task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
        String newName = "Sarah Johnson";

        task.setName(newName);
        assertEquals(newName, task.getName());
    }

    @Test
    @DisplayName("setName() rejects null")
    void testSetNameNull() {
        Task task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);

        assertThrows(IllegalArgumentException.class,
                () -> task.setName(null));
    }

    @Test
    @DisplayName("setName() rejects too long name")
    void testSetNameTooLong() {
        Task task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);

        assertThrows(IllegalArgumentException.class,
                () -> task.setName("Extremely long name that should definitely be rejected"));
    }

    @Test
    @DisplayName("setName() rejects empty string")
    void testSetNameEmpty() {
        Task task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);

        assertThrows(IllegalArgumentException.class,
                () -> task.setName(""));
    }

    // ───────────────────────────────────────────────
    //  Setter Tests – Description (if setters exist)
    // ───────────────────────────────────────────────

    // Add similar tests for setDescription() if your Task class has that method

    /*
    @Test
    @DisplayName("setDescription() accepts valid description")
    void testSetDescriptionValid() { ... }

    @Test
    @DisplayName("setDescription() rejects null") { ... }
    */
}