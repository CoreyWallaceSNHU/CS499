/*
 * Corey Wallace
 * CS320
 * SNHU
 */

package Main;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the TaskService class.
 */
@DisplayName("TaskService Unit Tests")
class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
        // Note: Assuming TaskService has a static Map<String, Task> tasks
        // If tasks is not static → adjust to taskService.getTasks().clear() or similar
    }

    @AfterEach
    void tearDown() {
        TaskService.tasks.clear();  // safe to keep if static; otherwise remove or adapt
    }

    // ───────────────────────────────────────────────
    //  Add Task Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("Adding a task generates unique ID and stores correctly")
    void testAddUniqueTask_Success() {
        String name = "Greg Tippton";
        String description = "This is a good description";

        assertEquals(0, TaskService.tasks.size(), "Service should start empty");

        taskService.addUniqueTask(name, description);

        assertEquals(1, TaskService.tasks.size(), "One task should be added");

        // Get the only task (assuming auto-generated ID)
        Task addedTask = TaskService.tasks.values().iterator().next();

        assertNotNull(addedTask.getUniqueID(), "Task should have an ID");
        assertEquals(name, addedTask.getName(), "Name should match");
        assertEquals(description, addedTask.getDescription(), "Description should match");
    }

    // ───────────────────────────────────────────────
    //  Delete Task Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("Deleting an existing task removes it; deleting non-existent does nothing")
    void testDeleteTask() {
        String name = "Greg Tippton";
        String description = "This is a good description";

        taskService.addUniqueTask(name, description); // ID "0" or auto-generated
        taskService.addUniqueTask(name, description); // ID "1"
        taskService.addUniqueTask(name, description); // ID "2"

        assertEquals(3, TaskService.tasks.size(), "Three tasks should be present");

        String idToDelete = "1"; // assumes sequential IDs starting from "0"
        taskService.deleteTasks(idToDelete);

        assertEquals(2, TaskService.tasks.size(), "Should have two tasks left");
        assertFalse(TaskService.tasks.containsKey(idToDelete), "Deleted ID should be gone");

        // Attempt to delete again (non-existent) → should not throw or change size
        taskService.deleteTasks(idToDelete);
        assertEquals(2, TaskService.tasks.size(), "Size should remain unchanged");
    }

    // ───────────────────────────────────────────────
    //  Update Task Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("Updating an existing task with valid data succeeds")
    void testUpdateTask_ValidId() {
        String initialName = "Greg Tippton";
        String initialDesc = "This is a good description";
        String newDesc = "New updated description";

        taskService.addUniqueTask(initialName, initialDesc);

        // Assuming ID generation starts at "0" or similar
        String taskId = TaskService.tasks.keySet().iterator().next();

        taskService.updateTasks(taskId, initialName, newDesc);

        Task updated = TaskService.tasks.get(taskId);

        assertEquals(initialName, updated.getName(), "Name should remain unchanged");
        assertEquals(newDesc, updated.getDescription(), "Description should be updated");
    }

    @Test
    @DisplayName("Updating a non-existent task does not modify existing tasks")
    void testUpdateTask_InvalidId() {
        String name = "Greg Tippton";
        String description = "This is a good description";
