/*
 * Corey Wallace
 * CS320
 * SNHU
 */

package Main;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Contact class.
 */
@DisplayName("Contact Class Unit Tests")
class ContactTest {

    private static final String VALID_ID          = "1234567890";
    private static final String VALID_FIRST_NAME  = "Greg";
    private static final String VALID_LAST_NAME   = "Hoffman";
    private static final String VALID_PHONE       = "1234567890";
    private static final String VALID_ADDRESS     = "123 Main Street";

    private Contact contact;

    @BeforeEach
    void setUp() {
        contact = new Contact(VALID_ID, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PHONE, VALID_ADDRESS);
    }

    // ───────────────────────────────────────────────
    //  Constructor Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("Constructor accepts valid inputs")
    void testValidConstructor() {
        assertEquals(VALID_ID,         contact.getContactID());
        assertEquals(VALID_FIRST_NAME, contact.getFirstName());
        assertEquals(VALID_LAST_NAME,  contact.getLastName());
        assertEquals(VALID_PHONE,      contact.getPhoneNumber());
        assertEquals(VALID_ADDRESS,    contact.getAddress());
    }

    @Test
    @DisplayName("Constructor rejects null ID")
    void testConstructorNullId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    @DisplayName("Constructor rejects too long ID")
    void testConstructorIdTooLong() {
        String tooLongId = "12345678901"; // assuming max 10 chars
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(tooLongId, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    @DisplayName("Constructor rejects invalid phone number (wrong length)")
    void testConstructorInvalidPhone() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, VALID_FIRST_NAME, VALID_LAST_NAME, "123", VALID_ADDRESS));

        assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, VALID_FIRST_NAME, VALID_LAST_NAME, "12345678901", VALID_ADDRESS));
    }

    // ───────────────────────────────────────────────
    //  First Name Setter Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("setFirstName accepts valid name")
    void testSetFirstNameValid() {
        contact.setFirstName("Sarah");
        assertEquals("Sarah", contact.getFirstName());
    }

    @Test
    @DisplayName("setFirstName rejects null")
    void testSetFirstNameNull() {
        assertThrows(IllegalArgumentException.class,
                () -> contact.setFirstName(null));
    }

    @Test
    @DisplayName("setFirstName rejects too long name")
    void testSetFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> contact.setFirstName("ThisFirstNameIsDefinitelyWayTooLong"));
    }

    // ───────────────────────────────────────────────
    //  Last Name Setter Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("setLastName accepts valid name")
    void testSetLastNameValid() {
        contact.setLastName("Johnson");
        assertEquals("Johnson", contact.getLastName());
    }

    @Test
    @DisplayName("setLastName rejects null")
    void testSetLastNameNull() {
        assertThrows(IllegalArgumentException.class,
                () -> contact.setLastName(null));
    }

    @Test
    @DisplayName("setLastName rejects too long name")
    void testSetLastNameTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> contact.setLastName("ThisLastNameIsWayTooLongToBeAccepted"));
    }

    // ───────────────────────────────────────────────
    //  Phone Number Setter Tests
    // ───────────────────────────────────────────────

    @Test
    @DisplayName("setPhoneNumber accepts valid 10-digit phone")
    void testSetPhoneNumberValid() {
        contact.setPhoneNumber("9876543210");
        assertEquals("9876543210", contact.getPhoneNumber());
    }

    @Test
    @DisplayName("setPhoneNumber rejects null")
    void testSetPhoneNumberNull() {
        assertThrows(IllegalArgumentException.class,
                () -> contact.setPhoneNumber(null));
    }

    @Test
    @Display