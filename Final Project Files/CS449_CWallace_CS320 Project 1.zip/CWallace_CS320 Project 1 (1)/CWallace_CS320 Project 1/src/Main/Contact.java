/*
 * Corey Wallace
 * CS320
 * SNHU
 */

package main;  // lowercase is conventional in Java

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Service class responsible for managing a collection of Contact objects.
 * Provides methods to add, delete, and update contacts using unique string IDs.
 */
public final class ContactService {

    private final List<Contact> contacts = new ArrayList<>();
    private int nextId = 0;  // Simple incrementing counter for IDs

    /**
     * Adds a new contact with an auto-generated unique ID.
     *
     * @param firstName    the contact's first name
     * @param lastName     the contact's last name
     * @param phoneNumber  the contact's 10-digit phone number
     * @param address      the contact's address
     * @return the generated ID of the newly added contact
     * @throws IllegalArgumentException if any parameter is invalid (delegated to Contact constructor)
     */
    public String addContact(String firstName, String lastName, String phoneNumber, String address) {
        String id = String.valueOf(nextId++);
        Contact contact = new Contact(id, firstName, lastName, phoneNumber, address);
        contacts.add(contact);
        return id;
    }

    /**
     * Removes the contact with the specified ID if it exists.
     *
     * @param id the ID of the contact to delete
     * @return true if a contact was removed, false if not found
     */
    public boolean deleteContact(String id) {
        if (id == null) {
            return false;
        }
        return contacts.removeIf(contact -> id.equals(contact.getContactID()));
    }

    /**
     * Updates the first name of the contact with the given ID.
     *
     * @param id        the ID of the contact to update
     * @param firstName the new first name
     * @throws IllegalArgumentException if contact not found or name is invalid
     */
    public void updateFirstName(String id, String firstName) {
        findContactById(id)
                .orElseThrow(() -> new IllegalArgumentException("Contact with ID " + id + " not found"))
                .setFirstName(firstName);
    }

    /**
     * Updates the last name of the contact with the given ID.
     *
     * @param id       the ID of the contact to update
     * @param lastName the new last name
     * @throws IllegalArgumentException if contact not found or name is invalid
     */
    public void updateLastName(String id, String lastName) {
        findContactById(id)
                .orElseThrow(() -> new IllegalArgumentException("Contact with ID " + id + " not found"))
                .setLastName(lastName);
    }

    /**
     * Updates the phone number of the contact with the given ID.
     *
     * @param id          the ID of the contact to update
     * @param phoneNumber the new 10-digit phone number
     * @throws IllegalArgumentException if contact not found or phone is invalid
     */
    public void updatePhoneNumber(String id, String phoneNumber) {
        findContactById(id)
                .orElseThrow(() -> new IllegalArgumentException("Contact with ID " + id + " not found"))
                .setPhoneNumber(phoneNumber);
    }

    /**
     * Updates the address of the contact with the given ID.
     *
     * @param id      the ID of the contact to update
     * @param address the new address
     * @throws IllegalArgumentException if contact not found or address is invalid
     */
    public void updateAddress(String id, String address) {
        findContactById(id)
                .orElseThrow(() -> new IllegalArgumentException("Contact with ID " + id + " not found"))
                .setAddress(address);
    }

    /**
     * Returns the number of contacts currently stored.
     */
    public int getContactCount() {
        return contacts.size();
    }

    /**
     * Retrieves a contact by its ID.
     *
     * @param id the ID to search for
     * @return an Optional containing the contact if found, or empty
     */
    public Optional<Contact> getContact(String id) {
        return findContactById(id);
    }

    /**
     * Clears all contacts (primarily for testing).
     */
    public void clearAllContacts() {
        contacts.clear();
        nextId = 0;  // Optional: reset ID sequence
    }

    // ───────────────────────────────────────────────
    //  Helper Methods
    // ───────────────────────────────────────────────

    private Optional<Contact> findContactById(String id) {
        if (id == null) {
            return Optional.empty();
        }
        return contacts.stream()
                .filter(contact -> id.equals(contact.getContactID()))
                .findFirst();
    }
}