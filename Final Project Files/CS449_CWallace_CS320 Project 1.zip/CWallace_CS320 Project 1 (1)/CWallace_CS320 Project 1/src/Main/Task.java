/*
 * Corey Wallace
 * CS320 - Software Testing
 * SNHU
 */

package main;  // ← lowercase package name (Java convention)

import java.util.Objects;

/**
 * Represents a task with a unique ID, name, and description.
 * All fields are validated upon creation and updates.
 * The ID is immutable after construction.
 */
public class Task {

    private final String id;           // uniqueID → id (shorter & conventional)
    private String name;               // fullName → name (more accurate for a task)
    private String description;

    // -------------------------------------------------------------------------
    // Validation helpers (static, pure functions)
    // -------------------------------------------------------------------------

    private static boolean isValidId(String id) {
        return id != null &&
               !id.isBlank() &&
               id.length() <= 10;
    }

    private static boolean isValidName(String name) {
        return name != null &&
               !name.isBlank() &&
               name.length() <= 20;
    }

    private static boolean isValidDescription(String description) {
        return description != null &&
               !description.isBlank() &&
               description.length() <= 50;
    }

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /**
     * Creates a new Task with the specified values.
     *
     * @param id          unique identifier (1–10 characters, non-null, non-blank)
     * @param name        task name (1–20 characters, non-null, non-blank)
     * @param description task description (1–50 characters, non-null, non-blank)
     * @throws IllegalArgumentException if any parameter fails validation
     */
    public Task(String id, String name, String description) {
        if (!isValidId(id)) {
            throw new IllegalArgumentException(
                    "Invalid task ID: must be 1-10 characters, non-null, non-blank");
        }
        if (!isValidName(name)) {
            throw new IllegalArgumentException(
                    "Invalid task name: must be 1-20 characters, non-null, non-blank");
        }
        if (!isValidDescription(description)) {
            throw new IllegalArgumentException(
                    "Invalid description: must be 1-50 characters, non-null, non-blank");
        }

        this.id = id;
        this.name = name;
        this.description = description;
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    /**
     * @return the unique task ID (immutable)
     */
    public String getId() {
        return id;
    }

    /**
     * @return the task name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the task description
     */
    public String getDescription() {
        return description;
    }

    // -------------------------------------------------------------------------
    // Setters (with validation) — ID has no setter (immutable)
    // -------------------------------------------------------------------------

    /**
     * Updates the task name.
     *
     * @param name new name (1–20 characters, non-null, non-blank)
     * @throws IllegalArgumentException if name is invalid
     */
    public void setName(String name) {
        if (!isValidName(name)) {
            throw new IllegalArgumentException(
                    "Invalid task name: must be 1-20 characters, non-null, non-blank");
        }
        this.name = name;
    }

    /**
     * Updates the task description.
     *
     * @param description new description (1–50 characters, non-null, non-blank)
     * @throws IllegalArgumentException if description is invalid
     */
    public void setDescription(String description) {
        if (!isValidDescription(description)) {
            throw new IllegalArgumentException(
                    "Invalid description: must be 1-50 characters, non-null, non-blank");
        }
        this.description = description;
    }

    // Optional: equals, hashCode, toString for testing/debugging
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return id.equals(task.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Task{" +
               "id='" + id + '\'' +
               ", name='" + name + '\'' +
               ", description='" + description + '\'' +
               '}';
    }
}