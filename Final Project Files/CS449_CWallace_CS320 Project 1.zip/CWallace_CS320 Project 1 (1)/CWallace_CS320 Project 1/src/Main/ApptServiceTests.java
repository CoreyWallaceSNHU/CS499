/*
 * Corey Wallace
 * CS320 - Software Testing
 * SNHU
 */

package main;  // lowercase package name (convention)

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the AppointmentService class.
 * Validates adding, deleting, and updating appointments.
 */
@DisplayName("AppointmentService Tests")
class AppointmentServiceTest {

    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();

        Calendar cal = Calendar.getInstance();
        cal.set(2025, Calendar.DECEMBER, 5, 10, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        futureDate = cal.getTime();
    }

    @AfterEach
    void tearDown() {
        // Clear shared static map after each test (only needed if using the original static version)
        // In a better design, this would not be necessary — see notes below
        AppointmentService.appointments.clear();
    }

    // -------------------------------------------------------------------------
    // Add Appointment Tests
    // -------------------------------------------------------------------------

    @Test
    @DisplayName("Should add a valid appointment and auto-generate ID")
    void shouldAddValidAppointment() {
        String description = "Annual physical check-up";

        assertEquals(0, service.getAppointmentCount());

        String generatedId = service.addAppointment(futureDate, description);

        assertEquals(1, service.getAppointmentCount());
        assertTrue(service.getAllAppointments().containsKey(generatedId));

        Appointment added = service.getAllAppointments().get(generatedId);
        assertEquals(futureDate, added.getDate());
        assertEquals(description, added.getDescription());
    }

    @Test
    @DisplayName("Should throw exception when adding appointment with null description")
    void shouldThrowWhenAddingWithNullDescription() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(futureDate, null)
        );
        assertEquals("Invalid description: must be 1-50 characters, non-null, non-blank", ex.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when adding appointment with empty description")
    void shouldThrowWhenAddingWithEmptyDescription() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(futureDate, "")
        );
        assertEquals("Invalid description: must be 1-50 characters, non-null, non-blank", ex.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when adding appointment with blank description")
    void shouldThrowWhenAddingWithBlankDescription() {
        IllegalArgumentException ex = assertThrows(
                Illegal