# Setup the Dash application    
from dash import Dash, dcc, html, dash_table
from dash.dependencies import Input, Output

# Configure the plotting routines
import plotly.express as px
import pandas as pd
import dash_leaflet as dl
import base64

# Import your CRUD module
from animal_shelter import AnimalShelter

# Connect to MongoDB
username = "aacuser"
password = "CWallaceSNHU"
host = 'nv-desktop-services.apporto.com'
port = 34067
db_name = 'AAC'
collection_name = 'animals'

# Instantiate the AnimalShelter class
try:
    shelter = AnimalShelter(username, password, host=host, port=port, db_name=db_name, collection_name=collection_name)
    print("Successfully connected to MongoDB (or using mock).")
    # Optional: Print a sample population report to demonstrate the new feature
    try:
        report = shelter.generate_population_report()
        print("Sample Population Report:", report)
    except Exception:
        # If using mock or no data present, ignore
        pass
except Exception as e:
    print(f"Failed to connect to MongoDB: {e}")
    # Do not exit; fallback to in-memory/mock behavior if provided by animal_shelter
    try:
        shelter = AnimalShelter()
        print("Using fallback AnimalShelter.")
    except Exception as ex:
        import sys
        sys.exit(f"Database connection failed and no fallback available: {ex}")

# Define filter queries based on the "Rescue Type and Preferred Dog Breeds Table"
RESCUE_FILTERS = {
    "Water Rescue": {
        "animal_type": "Dog",
        "breed": {"$in": ["Labrador Retriever", "Chesapeake Bay Retriever", "Newfoundland"]},
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}  # 6 months to 3 years
    },
    "Mountain or Wilderness Rescue": {
        "animal_type": "Dog",
        "breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]},
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}  # 6 months to 3 years
    },
    "Disaster or Individual Tracking": {
        "animal_type": "Dog",
        "breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]},
        "sex_upon_outcome": "Intact Female",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}  # 6 months to 3 years
    },
    "Reset": {}  # Empty query to retrieve all documents
}

# Initial data load for the "Reset" state
try:
    initial_df = pd.DataFrame.from_records(shelter.read({}))
except Exception:
    initial_df = pd.DataFrame()

# Drop the MongoDB '_id' column
if '_id' in initial_df.columns:
    initial_df = initial_df.drop(columns=['_id'])

# Ensure DataTable has at least one column to avoid runtime errors
if initial_df.empty:
    columns = [{"name": "No Data", "id": "No Data"}]
    initial_data = []
else:
    columns = [{"name": i, "id": i, "deletable": False, "selectable": True} for i in initial_df.columns]
    initial_data = initial_df.to_dict('records')

# Initialize the Dash app
app = Dash(__name__)

# Path to the logo file (assuming it's in the same directory)
logo_path = "Grazioso_Salvare_logo.png"

# Read the image and encode it to Base64
try:
    with open(logo_path, "rb") as image_file:
        encoded_image = base64.b64encode(image_file.read()).decode('ascii')
    grazioso_salvare_logo_src = f"data:image/png;base64,{encoded_image}"
    print(f"Successfully loaded and encoded logo from: {logo_path}")
except FileNotFoundError:
    print(f"Warning: Logo file not found at {logo_path}. Using a placeholder image.")
    grazioso_salvare_logo_src = "https://placehold.co/200x80/cccccc/333333?text=Grazioso+Salvare+Logo"
except Exception as e:
    print(f"Error processing logo file: {e}. Using a placeholder image.")
    grazioso_salvare_logo_src = "https://placehold.co/200x80/cccccc/333333?text=Grazioso+Salvare+Logo"

# Layout of the Dash app
app.layout = html.Div([
    # Hidden div for any potential future client-side data storage or triggers
    html.Div(id='hidden-div', style={'display':'none'}),

    # Header with logo and unique identifier
    html.Div([
        # Use the Base64 encoded image source
        html.Img(src=grazioso_salvare_logo_src, style={'height':'80px', 'float':'left', 'margin-right':'20px'}),
        html.Center(html.B(html.H1('Corey Wallace SNHU CS-340 Dashboard'))),
    ], style={'display': 'flex', 'align-items': 'center', 'justify-content': 'center', 'margin-bottom': '20px'}),

    html.Hr(),

    # Interactive Filter Options (Radio Buttons)
    html.Div([
        html.H3("Rescue Type Filters:"),
        dcc.RadioItems(
            id='filter-radio-items',
            options=[{'label': k, 'value': k} for k in RESCUE_FILTERS.keys()],
            value='Reset',  # Default selected value
            labelStyle={'display': 'inline-block', 'margin-right': '15px'},
            style={'margin-bottom': '20px'}
        ),
    ], style={'text-align': 'center', 'padding': '10px'}),

    html.Hr(),

    # Data Table
    html.Div([
        html.H3("Animal Outcomes Data Table"),
        dash_table.DataTable(
            id='datatable-id',
            columns=columns,
            data=initial_data,
            filter_action="native",  # Allows filtering directly in the table
            sort_action="native",    # Allows sorting columns
            row_selectable="single", # Allows selecting a single row
            selected_rows=[0] if initial_data else [],
            page_action="native",    # Enables pagination
            page_current=0,
            page_size=10,            # Displays 10 rows per page
            style_table={'overflowX': 'auto', 'margin-bottom': '20px'},
            style_cell={
                'height': 'auto',
                'minWidth': '100px', 'width': '100px', 'maxWidth': '180px',
                'whiteSpace': 'normal',
                'textAlign': 'left'
            },
            style_header={
                'backgroundColor': 'rgb(230, 230, 230)',
                'fontWeight': 'bold'
            },
            style_data_conditional=[
                {
                    'if': {'row_index': 'odd'},
                    'backgroundColor': 'rgb(248, 248, 248)'
                }
            ]
        ),
    ]),

    html.Br(),
    html.Hr(),

    # Charts Section
    html.Div([
        html.H3("Data Visualizations"),
        html.Div([
            # Geolocation Chart (Map)
            html.Div(
                id='map-container',  # Container for the map
                children=[
                    dl.Map(style={'width': '100%', 'height': '500px', 'border-radius': '8px'},
                           center=[30.75, -97.48], zoom=10, children=[
                        dl.TileLayer(id="base-layer-id"),
                        # Marker will be added dynamically by callback
                    ])
                ],
                style={'width': '49%', 'display': 'inline-block', 'vertical-align': 'top', 'padding': '10px'}
            ),

            # Second Chart (Pie Chart for Animal Types)
            html.Div(
                dcc.Graph(id='animal-type-pie-chart', style={'border-radius': '8px'}),
                style={'width': '49%', 'display': 'inline-block', 'vertical-align': 'top', 'padding': '10px'}
            )
        ], style={'display': 'flex', 'justify-content': 'space-around', 'flex-wrap': 'wrap'})
    ]),
    html.Hr(),
    html.Center(html.P("Dashboard created by Corey Wallace for SNHU CS-340"))  # Unique identifier again
])

# Utility to find latitude/longitude columns
def _find_lat_lon_columns(df: pd.DataFrame):
    lat_candidates = ['latitude', 'lat', 'Latitude', 'Lat']
    lon_candidates = ['longitude', 'lon', 'lng', 'long', 'Longitude', 'Lon']
    lat_col = next((c for c in lat_candidates if c in df.columns), None)
    lon_col = next((c for c in lon_candidates if c in df.columns), None)
    return lat_col, lon_col

# Callback to update the data table, map, and pie chart based on filter selection
@app.callback(
    Output('datatable-id', 'data'),
    Output('map-container', 'children'),  # Update the map component itself
    Output('animal-type-pie-chart', 'figure'),
    Input('filter-radio-items', 'value')
)
def update_dashboard(selected_filter_value):
    print(f"Selected filter: {selected_filter_value}")
    query = RESCUE_FILTERS.get(selected_filter_value, {})
    print(f"Executing query: {query}")

    # Fetch data from MongoDB based on the selected filter
    try:
        filtered_data_list = shelter.read(query) or []
    except Exception as e:
        print(f"Error reading from shelter: {e}")
        filtered_data_list = []

    df_filtered = pd.DataFrame.from_records(filtered_data_list)

    # Drop '_id' column if it exists
    if '_id' in df_filtered.columns:
        df_filtered = df_filtered.drop(columns=['_id'])

    # Prepare DataTable data
    if df_filtered.empty:
        table_data = []
        # Keep the same map with just the tile layer
        map_children = [
            dl.Map(style={'width': '100%', 'height': '500px', 'border-radius': '8px'},
                   center=[30.75, -97.48], zoom=10, children=[dl.TileLayer(id="base-layer-id")])
        ]
        # Create an empty/placeholder pie chart
        pie_fig = px.pie(names=["No Data"], values=[1], title="No Data")
    else:
        table_data = df_filtered.to_dict('records')

        # Build map markers if coordinates exist
        lat_col, lon_col = _find_lat_lon_columns(df_filtered)
        markers = []
        if lat_col and lon_col:
            for _, row in df_filtered.iterrows():
                try:
                    lat = float(row[lat_col])
                    lon = float(row[lon_col])
                    label = str(row.get('animal_id') or row.get('name') or '')
                    markers.append(dl.Marker(position=[lat, lon], children=dl.Tooltip(label)))
                except Exception:
                    # Skip invalid coordinates
                    continue

        map_children = [
            dl.Map(style={'width': '100%', 'height': '500px', 'border-radius': '8px'},
                   center=[30.75, -97.48], zoom=10,
                   children=[dl.TileLayer(id="base-layer-id")] + markers)
        ]

        # Create pie chart for animal types if present
        if 'animal_type' in df_filtered.columns and not df_filtered['animal_type'].dropna().empty:
            try:
                pie_fig = px.pie(df_filtered, names='animal_type', title="Animal Types Distribution")
            except Exception as e:
                print(f"Error creating pie chart: {e}")
                pie_fig = px.pie(names=["Unknown"], values=[1], title="No Data")
        else:
            pie_fig = px.pie(names=["No Data"], values=[1], title="No Data")

    return table_data, map_children, pie_fig

if __name__ == '__main__':
    app.run_server(debug=True)