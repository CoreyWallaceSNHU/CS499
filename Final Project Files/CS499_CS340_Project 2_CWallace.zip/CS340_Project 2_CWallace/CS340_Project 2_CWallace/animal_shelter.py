try:
    from pymongo import MongoClient
    from pymongo.errors import PyMongoError
    _USE_PYMONGO = True
except ModuleNotFoundError:
    # Fallback in-memory/mock implementation so the module can run without pymongo
    _USE_PYMONGO = False
    class PyMongoError(Exception):
        pass

    class _InsertOneResult:
        def __init__(self, acknowledged: bool):
            self.acknowledged = acknowledged

    class _UpdateResult:
        def __init__(self, modified_count: int):
            self.modified_count = modified_count

    class _DeleteResult:
        def __init__(self, deleted_count: int):
            self.deleted_count = deleted_count

    class _MockCollection:
        def __init__(self):
            self._docs = []
            self._next_id = 1

        def create_index(self, *args, **kwargs):
            return None

        def insert_one(self, data):
            doc = dict(data)
            if '_id' not in doc:
                doc['_id'] = self._next_id
                self._next_id += 1
            self._docs.append(doc)
            return _InsertOneResult(True)

        def find(self, query=None):
            if not query:
                return list(self._docs)
            results = []
            for d in self._docs:
                match = True
                for k, v in query.items():
                    if d.get(k) != v:
                        match = False
                        break
                if match:
                    results.append(d)
            return results

        def update_many(self, query, update):
            set_vals = update.get('$set', {})
            count = 0
            for d in self._docs:
                match = True
                for k, v in query.items():
                    if d.get(k) != v:
                        match = False
                        break
                if match:
                    d.update(set_vals)
                    count += 1
            return _UpdateResult(count)

        def delete_many(self, query):
            original = len(self._docs)
            remaining = []
            for d in self._docs:
                match = True
                for k, v in query.items():
                    if d.get(k) != v:
                        match = False
                        break
                if not match:
                    remaining.append(d)
            deleted = original - len(remaining)
            self._docs = remaining
            return _DeleteResult(deleted)

        def aggregate(self, pipeline):
            # Minimal support for the specific aggregation used in this project
            if not pipeline:
                return []
            # support the group-by + sort used in generate_population_report
            group_stage = pipeline[0].get('$group') if isinstance(pipeline[0], dict) else None
            if not group_stage:
                return []
            id_spec = group_stage.get('_id', {})
            counts = {}
            for d in self._docs:
                key = tuple((k, d.get(v.lstrip('$'))) for k, v in id_spec.items())
                counts[key] = counts.get(key, 0) + 1
            results = []
            for key, cnt in counts.items():
                id_obj = {k: val for k, val in key}
                results.append({'_id': id_obj, 'count': cnt})
            # simple sort if provided
            if len(pipeline) > 1 and isinstance(pipeline[1], dict) and '$sort' in pipeline[1]:
                # try to mimic the sort used in this file
                results.sort(key=lambda x: (x['_id'].get('type'), -x['count']))
            return results

    class _MockClient:
        def __init__(self, *args, **kwargs):
            self._dbs = {}

        def __getitem__(self, db_name):
            if db_name not in self._dbs:
                self._dbs[db_name] = {}
            return _MockDatabase(self._dbs, db_name)

    class _MockDatabase:
        def __init__(self, dbs, name):
            self._dbs = dbs
            self._name = name

        def __getitem__(self, coll_name):
            if coll_name not in self._dbs[self._name]:
                self._dbs[self._name][coll_name] = _MockCollection()
            return self._dbs[self._name][coll_name]

    def MongoClient(*args, **kwargs):
        return _MockClient(*args, **kwargs)

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username='aacuser', password='CWallaceSNHU', host='nv-desktop-services.apporto.com', port=34067, db_name='AAC', collection_name='animals'):
        """Initialize MongoDB connection and create indexes"""
        try:
            self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/")
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
            # Create indexes for frequently queried fields (idempotent if they exist)
            self.collection.create_index("animal_id", unique=True)
            self.collection.create_index("animal_type")
            self.collection.create_index("breed")
        except PyMongoError as e:
            print(f"Connection error: {e}")
            raise

    def create(self, data):
        """Insert a document into the collection"""
        if data:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except PyMongoError as e:
                print(f"Create error: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, query=None):
        """Query documents from the collection"""
        if query is None:
            query = {}
        try:
            return list(self.collection.find(query))
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, new_values):
        """Update document(s) in the collection"""
        if query and new_values:
            try:
                result = self.collection.update_many(query, {'$set': new_values})
                return result.modified_count
            except PyMongoError as e:
                print(f"Update error: {e}")
                return 0
        else:
            raise ValueError("Query or new_values parameter is empty")

    def delete(self, query):
        """Delete document(s) from the collection"""
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except PyMongoError as e:
                print(f"Delete error: {e}")
                return 0
        else:
            raise ValueError("Query parameter is empty")

    def aggregate(self, pipeline):
        """Perform aggregation operations for complex queries"""
        if not pipeline:
            raise ValueError("Pipeline parameter is empty")
        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as e:
            print(f"Aggregate error: {e}")
            return []

    def generate_population_report(self):
        """Generate a report on animal population using aggregation.
        Groups by type, breed, and outcome status (e.g., adoption status).
        You can extend the pipeline for additional filters like age.
        """
        pipeline = [
            {
                "$group": {
                    "_id": {
                        "type": "$animal_type",
                        "breed": "$breed",
                        "status": "$outcome_type"
                    },
                    "count": {"$sum": 1}
                }
            },
            {"$sort": {"_id.type": 1, "count": -1}}
        ]
        return self.aggregate(pipeline)